function submitForm(){
    document.getElementById("book_car").submit();
}